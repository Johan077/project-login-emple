
package Modelo;

public class Salario extends Horas{
    int vrh;

    public int getVrh() {
        return vrh;
    }

    public Salario(int vrh, int hr, String ced, String nom, String tel) {
        super(hr, ced, nom, tel);
        this.vrh = vrh;
    }
    public int calcular(){
        int sueldo;
        sueldo=getVrh()*gethr();
        return sueldo;
    }
    
}
