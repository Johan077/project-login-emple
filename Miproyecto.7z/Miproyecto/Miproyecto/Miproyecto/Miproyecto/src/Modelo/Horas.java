/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Horas extends Emple{
    int hr;

    public int gethr() {
        return hr;
    }

    public Horas(int hora, String ced, String nom, String tel) {
        super(ced, nom, tel);
        this.hr = hr;
    }
    
}
