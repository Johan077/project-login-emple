/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Salario extends Horas{
    int vrh;

    public int getVrh() {
        return vrh;
    }

    public Salario(int vrh, int hora, String ced, String nom, String tel) {
        super(hora, ced, nom, tel);
        this.vrh = vrh;
    }
    public int calcular(){
        int sueldo;
        sueldo=getVrh()*getHora();
        return sueldo;
    }
    
}
