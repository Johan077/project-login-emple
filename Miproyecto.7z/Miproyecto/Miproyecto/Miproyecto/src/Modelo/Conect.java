package Model;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author julian.bautista
 */
public class Conect {

    private static Connection conex ;
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user = "root";
    private static final String password = "";
    private static final String url = "jdbc:mysql://localhost:3306/nomina";

    private Conect() {        
    }

    public static Connection getConnection() {
        if(conex==null){
            try {
            Class.forName(driver);
            conex = DriverManager.getConnection(url, user, password);
            if (conex != null) {
                System.out.println("Conexion establecida");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("error de conexion " + e);

        }
        }
        return conex;
    }

    public static void desconectar() {
       conex= null;
       if (conex == null) {
                System.out.println("Conexion terminada");
            }
    }
    
    
}
